<html>
      <head>
        <title>jQuery Image Slideshow</title>
        <style>
		img.slide { 
			position: absolute; 
			display:none;
		} 
		</style>
		<script src="http://code.jquery.com/jquery-2.1.1.js"></script>
		<script>
		$(document).ready(function() {
			$(".slide:first").show();
			setInterval(function(){ Next($('.slide:visible'))}, 2400);

		});
		function Next(slide) {
			slide.fadeOut();
			if(typeof slide.next().attr('src') !== 'undefined') {
				slide.next().fadeIn();
			} else {
				$('.slide:first').fadeIn();
			}
		}
		</script>
      </head>
      <body>
          <div>
            <img class="slide" src="slides/beach1.jpg"/>
			<img class="slide" src="slides/beach2.jpg"/>
			<img class="slide" src="slides/beach3.jpg"/>
			<img class="slide" src="slides/beach4.jpg"/>
			<img class="slide" src="slides/beach5.jpg"/>
          </div>
      </body>
</html>